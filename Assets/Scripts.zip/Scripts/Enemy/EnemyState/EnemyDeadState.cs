using UnityEngine;

public class EnemyDeadState : EnemyState
{
    private float timer = 0f;
    private float dissolveAmount = 0f;
    private float dissolveDelay = 1f;   // ��� �� ���� �ð�
    private float dissolveSpeed = 1f;
    private float dissolveEnd = 1f;
    private bool isDissolving = false;

    private Material dissolveMat;

    public EnemyDeadState(EnemyFSM enemy) : base(enemy) { }

    public override void Enter()
    {
        timer = 0f;
        dissolveAmount = 0f;
        isDissolving = false;

        // Rigidbody ���� ���� (���� ������ ���� ����)
        if (enemy.Rigidbody != null)
        {
            enemy.Rigidbody.useGravity = false;
            enemy.Rigidbody.velocity = Vector3.zero;
            enemy.Rigidbody.isKinematic = true;
        }

        // �ִϸ��̼� ���
        if (enemy.Animator != null)
        {
            enemy.Animator.SetTrigger("Die");
        }

        // �浹 ���� �ð� Ȯ��
        if (enemy.Collider != null)
        {
            enemy.Collider.enabled = true;
        }

        // Dissolve ��Ƽ���� �Ҵ�
        Renderer rend = enemy.GetComponentInChildren<Renderer>();
        if (rend != null)
        {
            dissolveMat = rend.material; // �ݵ�� �ν��Ͻ� ��Ƽ���� ���
            if (dissolveMat.HasProperty("_DissolveAmount"))
                dissolveMat.SetFloat("_DissolveAmount", 0f);
        }
    }

    public override void Update()
    {
        timer += Time.deltaTime;

        // Delay �� Dissolve ����
        if (!isDissolving && timer >= dissolveDelay)
        {
            isDissolving = true;

            // �浹 ����
            if (enemy.Collider != null)
                enemy.Collider.enabled = false;
        }

        if (isDissolving && dissolveMat != null)
        {
            dissolveAmount += Time.deltaTime * dissolveSpeed;

            // ���� ����� �α� ���
            Debug.Log($"[Dissolve] amount: {dissolveAmount}");

            if (dissolveMat.HasProperty("_DissolveAmount"))
                dissolveMat.SetFloat("_DissolveAmount", dissolveAmount);

            if (dissolveAmount >= dissolveEnd)
            {
                // ���� �Ǵ� Ǯ�� ��ȯ ó��
                GameObject.Destroy(enemy.gameObject);
            }
        }
    }

    public override void Exit()
    {
        
    }
}
