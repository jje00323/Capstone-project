using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.Experimental.Rendering.RayTracingAccelerationStructure;

public class JobManager : MonoBehaviour
{
    public enum JobType { Basic, Warrior, Mage, Archer }
    public JobType currentJob = JobType.Basic;

    public static JobManager Instance { get; private set; }

    private Dictionary<JobType, DashSettings> dashSettings;
    public List<JobResources> jobResourcesList;
    private Dictionary<JobType, JobResources> jobResourcesDict;

    public JobSkillData[] allJobSkillData;
    private Dictionary<JobType, JobSkillData> skillDataDict;

    [System.Serializable]
    public class JobResources
    {
        public JobManager.JobType jobType;
        public RuntimeAnimatorController animatorController;
        public Avatar avatar;
        public GameObject modelPrefab;
        public Transform rightHandBone;
    }

    [Header("���� ���� ��ġ")]
    public Transform modelParent;

    private GameObject currentModel;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeJobResources();
            InitializeDashSettings();
            InitializeSkillData();
            Debug.Log("JobManager �ν��Ͻ� ������!");
        }
        else
        {
            Debug.LogWarning("JobManager �ߺ� ����! ���� �ν��Ͻ��� �����մϴ�.");
            Destroy(gameObject);
        }
    }

    void Start()
    {
        ChangeJob(currentJob);
    }

    private void InitializeDashSettings()
    {
        dashSettings = new Dictionary<JobType, DashSettings>
        {
            { JobType.Basic, new DashSettings(5f, 0.2f, 3f, true) },
            { JobType.Warrior, new DashSettings(3f, 0.15f, 4f, false) },
            { JobType.Mage, new DashSettings(7f, 0.3f, 5f, true) },
            { JobType.Archer, new DashSettings(6f, 0.25f, 6f, true) }
        };
    }

    private void InitializeSkillData()
    {
        skillDataDict = new Dictionary<JobType, JobSkillData>();
        foreach (var data in allJobSkillData)
        {
            if (!skillDataDict.ContainsKey(data.jobType))
            {
                skillDataDict[data.jobType] = data;
            }
        }
    }

    public JobSkillData GetSkillData(JobType jobType)
    {
        return skillDataDict.TryGetValue(jobType, out var data) ? data : null;
    }

    private void InitializeJobResources()
    {
        jobResourcesDict = new Dictionary<JobType, JobResources>();
        foreach (var resource in jobResourcesList)
        {
            if (!jobResourcesDict.ContainsKey(resource.jobType))
            {
                jobResourcesDict[resource.jobType] = resource;
            }
        }
    }

    public void ChangeJob(JobType newJob)
    {
        currentJob = newJob;

        if (!jobResourcesDict.ContainsKey(newJob))
        {
            Debug.LogError("�ش� ���� ���ҽ� ����: " + newJob);
            return;
        }

        var res = jobResourcesDict[newJob];
        GameObject player = GameObject.FindWithTag("Player");
        if (player == null)
        {
            Debug.LogError("Player ������Ʈ�� ã�� �� �����ϴ�.");
            return;
        }

        if (currentModel != null)
        {
            Destroy(currentModel);
        }

        currentModel = Instantiate(res.modelPrefab, modelParent);
        currentModel.transform.localPosition = Vector3.zero;
        currentModel.transform.localRotation = Quaternion.identity;

        Animator playerAnimator = player.GetComponent<Animator>();
        if (playerAnimator != null)
        {
            playerAnimator.runtimeAnimatorController = res.animatorController;
            playerAnimator.avatar = res.avatar;

            PlayerMovement movement = player.GetComponent<PlayerMovement>();
            if (movement != null)
                movement.UpdateAnimatorReference(playerAnimator);
        }


        PlayerSkillController playerSkill = FindObjectOfType<PlayerSkillController>();
        if (playerSkill != null)
        {
            var skillData = GetSkillData(newJob);
            if (skillData != null)
            {
                playerSkill.LoadSkillsFromData(skillData);
            }
        }
        var stateMachine = player.GetComponent<PlayerStateMachine>();
        if (stateMachine != null)
        {
            stateMachine.ChangeState(PlayerStateMachine.PlayerState.Idle);
        }
        var attack = player.GetComponent<PlayerAttack>();
        if (attack != null)
        {
            attack.ForceEndCombo(); 
        }
        // 2. ��ų UI ����
        PlayerSkillUI skillUI = FindObjectOfType<PlayerSkillUI>();
        if (skillUI != null)
        {
            var skillData = GetSkillData(newJob);
            if (skillData != null)
            {
                skillUI.ReloadUI(skillData);
            }
        }
        var playerMovement = player.GetComponent<PlayerMovement>();
        if (playerMovement != null)
            playerMovement.UpdateAnimatorReference(playerAnimator);

        var hips = playerAnimator.GetBoneTransform(HumanBodyBones.Hips);
        //Debug.Log("Hips ã�Ҵ°�? �� " + (hips != null ? hips.name : "null"));

        if (res.rightHandBone == null)
        {
            Debug.LogError($"[JobManager] '{newJob}' ������ rightHandBone�� �������� �ʾҽ��ϴ�!");
            return;
        }

        Transform instanceRightHand = currentModel.transform.Find(res.rightHandBone.name);
        if (instanceRightHand == null)
        {
            Debug.LogError("[JobManager] �ν��Ͻ����� �� ���� ã�� �� �����ϴ�!");
        }
        else
        {
            var equipmentSystem = player.GetComponent<WeaponEquipSystem>();
            if (equipmentSystem != null)
            {
                equipmentSystem.SetRightHand(instanceRightHand);
            }
        }
        Debug.Log($"[���� ���� �Ϸ�] {newJob}");
    }

    public DashSettings GetDashSettings()
    {
        return dashSettings[currentJob];
    }

    public JobType GetCurrentJob()
    {
        return currentJob;
    }

    public void ChangeToBasic() => ChangeJob(JobType.Basic);
    public void ChangeToWarrior() => ChangeJob(JobType.Warrior);
    public void ChangeToMage() => ChangeJob(JobType.Mage);
    public void ChangeToArcher() => ChangeJob(JobType.Archer);
}
