using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance { get; private set; }

    [Header("�κ��丮 ����")]
    public int maxSlotCount = 48;
    public List<InventorySlot> slots = new();

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        InitializeSlots();
    }

    private void InitializeSlots()
    {
        slots.Clear();
        for (int i = 0; i < maxSlotCount; i++)
        {
            slots.Add(new InventorySlot());
        }
    }

    /// <summary>
    /// �������� �κ��丮�� �߰�
    /// </summary>
    public bool AddItem(ItemData item, int amount)
    {
        Debug.Log($" [AddItem] {item.itemName} x{amount} �߰� �õ�");

        // 1. ���� ������ ���Կ� �߰�
        foreach (var slot in slots)
        {
            if (slot.item != null && slot.item == item && item.isStackable && slot.quantity < item.maxStack)
            {
                int space = item.maxStack - slot.quantity;
                int addAmount = Mathf.Min(space, amount);
                slot.quantity += addAmount;
                amount -= addAmount;

                Debug.Log($" [AddItem] ���õ� ���Կ� {addAmount} �߰��� (���� ����: {amount})");

                if (amount <= 0)
                {
                    RefreshQuickSlots(); //  ������ ����
                    return true;
                }
            }
        }

        // 2. �� ���Կ� ���� �߰�
        foreach (var slot in slots)
        {
            if (slot.item == null)
            {
                slot.item = item;
                slot.quantity = amount;
                Debug.Log($" [AddItem] �� ���Կ� {item.itemName} x{amount} �߰���");

                RefreshQuickSlots(); //  ������ ����
                return true;
            }
        }

        Debug.LogWarning($" [AddItem] ����: �� ���� ����. {item.itemName} x{amount} �߰� �Ұ�");
        return false;
    }

    /// <summary>
    /// ������ ����
    /// </summary>
    public void RemoveItem(ItemData targetItem, int amount = 1)
    {
        for (int i = 0; i < slots.Count; i++)
        {
            var slot = slots[i];
            if (slot.item == targetItem)
            {
                slot.quantity -= amount;

                if (slot.quantity <= 0)
                    slot.Clear();

                return;
            }
        }
    }

    private void RefreshQuickSlots()
    {
        QuickSlotUI[] quickSlots = GameObject.FindObjectsOfType<QuickSlotUI>();
        foreach (var qs in quickSlots)
        {
            qs.RefreshSlotUI();
        }
    }
}