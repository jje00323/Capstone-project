using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStatus : CharacterStatus
{
    public float maxMP = 50f;
    public float currentMP = 50f;

    public float maxEXP = 100f;
    public float currentEXP = 0f;

    public int level = 1;

    public PlayerUI playerUI;

    void Start()
    {
        UpdateAllUI();
    }

    public override void TakeDamage(float damage)
    {
        base.TakeDamage(damage);
        playerUI.UpdateHP(currentHP, maxHP);
        Debug.Log($"player ���� ü��: {currentHP}");
    }

    public override void Heal(float amount)
    {
        base.Heal(amount); // ���� Ŭ���� ��� ���
        playerUI?.UpdateHP(currentHP, maxHP); // UI ������Ʈ �� �÷��̾� ���� ó��
    }

    public void UseMana(float amount)
    {
        currentMP = Mathf.Clamp(currentMP - amount, 0, maxMP);
        playerUI.UpdateMP(currentMP, maxMP);
    }

    public void GainEXP(float amount)
    {
        currentEXP += amount;
        if (currentEXP >= maxEXP)
        {
            currentEXP -= maxEXP;
            level++;
            playerUI.UpdateLevel(level);
        }
        playerUI.UpdateEXP(currentEXP, maxEXP);
    }

    public void UpdateAllUI()
    {
        playerUI.UpdateHP(currentHP, maxHP);
        playerUI.UpdateMP(currentMP, maxMP);
        playerUI.UpdateEXP(currentEXP, maxEXP);
        playerUI.UpdateLevel(level);
    }

    protected override void OnDeath()
    {
        Debug.Log("�÷��̾� ��� ó��");
        // �÷��̾� ��� ó�� �߰�
    }
}

