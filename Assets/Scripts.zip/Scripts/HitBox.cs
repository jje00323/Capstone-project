using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hitbox : MonoBehaviour
{
    public enum ShapeType { Sphere, Box, Cone }

    [Header("��Ʈ�ڽ� ����")]
    public float damage = 10f;
    public float duration = 1f;

    [Header("�ݺ� ���� ����")]
    public float startDelay = 0f;
    public int repeatCount = 1;
    public float repeatInterval = 0.5f;

    [Header("���� ����")]
    public ShapeType shape = ShapeType.Sphere;
    public float radius = 2f;
    public Vector3 boxSize = new Vector3(2f, 2f, 2f);
    public float coneAngle = 45f;
    public float coneDistance = 3f;
    public Vector3 offset = Vector3.forward;

    [Header("����ü ����")]
    public bool isProjectile = false;
    public float projectileSpeed = 10f;
    public Rigidbody projectileRigidbody;

    [Header("�����")]
    public bool drawGizmos = true;
    public Color gizmoColor = Color.red;

    [SerializeField] private bool followCaster = false;

    private Transform caster;
    private bool initialized = false;
    private bool isHitboxActive = false;

    public void Initialize(Transform casterTransform, bool shouldFollow)
    {
        caster = casterTransform;
        followCaster = shouldFollow; // �ܺ� ���� �����ϰ� �ݿ�
        initialized = true;

        if (isProjectile)
            LaunchProjectile();
        else
            StartCoroutine(HandleHitbox());
    }

    private void Update()
    {
        if (!initialized || caster == null || !followCaster) return;

        transform.position = caster.position + caster.rotation * offset;
        transform.rotation = caster.rotation;
    }

    private void LaunchProjectile()
    {
        if (projectileRigidbody == null)
        {
            projectileRigidbody = GetComponent<Rigidbody>();
        }

        if (projectileRigidbody != null)
        {
            projectileRigidbody.velocity = transform.forward * projectileSpeed;
        }

        // ������ ���� ���� �� ���� �ð� �� ����
        StartCoroutine(DestroyAfterDuration());
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!isProjectile || !initialized) return;

        // ��Ʈ�ڽ��� �÷��̾� �����̸� ������ ����
        if (CompareTag("PlayerHitbox") && other.CompareTag("Enemy"))
        {
            EnemyStatus enemy = other.GetComponent<EnemyStatus>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage);
                Debug.Log($"[Hitbox Projectile] �� �ǰ�! ������: {damage}");
            }

            Destroy(gameObject);
        }
        // ��Ʈ�ڽ��� ���� �����̸� �÷��̾�� ����
        else if (CompareTag("EnemyHitbox") && other.CompareTag("Player"))
        {
            PlayerStatus player = other.GetComponent<PlayerStatus>();
            if (player != null)
            {
                player.TakeDamage(damage);
                Debug.Log($"[Hitbox Projectile] �÷��̾� �ǰ�! ������: {damage}");
            }

            Destroy(gameObject);
        }
    }

    private IEnumerator DestroyAfterDuration()
    {
        yield return new WaitForSeconds(duration);
        Destroy(gameObject);
    }

    private IEnumerator HandleHitbox()
    {
        yield return new WaitForSeconds(startDelay);

        for (int i = 0; i < repeatCount; i++)
        {
            isHitboxActive = true;        //  Ȱ��ȭ ����
            ApplyDamage();
            yield return new WaitForSeconds(0.1f); // ���� ���� �ð� (������)
            isHitboxActive = false;       //  ��Ȱ��ȭ

            if (i < repeatCount - 1)
                yield return new WaitForSeconds(repeatInterval);
        }

        yield return new WaitForSeconds(duration);
        Destroy(gameObject);
    }


    private void ApplyDamage()
    {
        if (!initialized)
        {
            Debug.LogWarning("[HitBox] �ʱ�ȭ���� ����");
            return;
        }

        Vector3 center = followCaster && caster != null
            ? caster.position + caster.TransformDirection(offset)
            : transform.position + transform.TransformDirection(offset);

        Collider[] hits = null;
        List<Collider> filteredHits = new List<Collider>();
        string targetLayer = gameObject.CompareTag("PlayerHitbox") ? "Enemy" : "Player";

        switch (shape)
        {
            case ShapeType.Sphere:
                hits = Physics.OverlapSphere(center, radius, LayerMask.GetMask(targetLayer));
                filteredHits.AddRange(hits);
                break;

            case ShapeType.Box:
                hits = Physics.OverlapBox(center, boxSize * 0.5f, transform.rotation, LayerMask.GetMask(targetLayer));
                filteredHits.AddRange(hits);
                break;

            case ShapeType.Cone:
                hits = Physics.OverlapSphere(center, coneDistance, LayerMask.GetMask(targetLayer));
                foreach (var col in hits)
                {
                    Vector3 dirToTarget = (col.transform.position - center).normalized;
                    float angle = Vector3.Angle(transform.forward, dirToTarget);
                    float distance = Vector3.Distance(center, col.transform.position);

                    if (distance <= 2f || angle < coneAngle * 0.7f)
                    {
                        filteredHits.Add(col);
                    }
                }
                break;
        }

        foreach (var col in filteredHits)
        {
            if (gameObject.CompareTag("PlayerHitbox") && col.CompareTag("Enemy"))
            {
                var enemy = col.GetComponent<EnemyStatus>();
                if (enemy != null) enemy.TakeDamage(damage);
            }
            else if (gameObject.CompareTag("EnemyHitbox") && col.CompareTag("Player"))
            {
                var player = col.GetComponent<PlayerStatus>();
                if (player != null) player.TakeDamage(damage);
            }
        }
    }

    private void OnDrawGizmos()
    {
        if (!drawGizmos) return;

        //  ����ü�� �ƴ� �Ϲ� ��Ʈ�ڽ��� ���� ���� ���� ������
        if (!isProjectile && Application.isPlaying && !isHitboxActive) return;


        Vector3 center;

        if (Application.isPlaying && caster != null && followCaster)
        {
            center = caster.position + caster.TransformDirection(offset);
        }
        else
        {
            center = transform.position + transform.TransformDirection(offset);
        }

        Gizmos.color = gizmoColor;

        switch (shape)
        {
            case ShapeType.Sphere:
                Gizmos.DrawWireSphere(center, radius);
                break;

            case ShapeType.Box:
                Gizmos.matrix = Matrix4x4.TRS(center, transform.rotation, Vector3.one);
                Gizmos.DrawWireCube(Vector3.zero, boxSize);
                Gizmos.matrix = Matrix4x4.identity;
                break;

            case ShapeType.Cone:
                Gizmos.DrawRay(center, transform.forward * coneDistance);
                Vector3 right = Quaternion.Euler(0, coneAngle * 0.5f, 0) * transform.forward;
                Vector3 left = Quaternion.Euler(0, -coneAngle * 0.5f, 0) * transform.forward;
                Gizmos.DrawRay(center, right * coneDistance);
                Gizmos.DrawRay(center, left * coneDistance);
                break;
        }
    }


}