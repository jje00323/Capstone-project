using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStatus : MonoBehaviour
{
    public float maxHP = 100f;
    public float currentHP = 100f;

    public virtual void TakeDamage(float damage)
    {
        currentHP = Mathf.Clamp(currentHP - damage, 0, maxHP);
        if (IsDead)
        {
            OnDeath();
        }
    }

    public virtual void Heal(float amount)
    {
        currentHP = Mathf.Clamp(currentHP + amount, 0, maxHP);
    }

    public bool IsDead => currentHP <= 0;

    protected virtual void OnDeath()
    {
        // �ڽ� Ŭ�������� ����
    }
}
